import 'client_base.dart';

/// Implemented in `browser_client.dart` and `io_client.dart`.
ClientBase createClient({required String endPoint, required bool selfSigned}) =>
    throw UnsupportedError(
        'Cannot create a client without dart:html or dart:io.');
