import 'package:path/path.dart' as path;

void main() {
  var x = path.join(null, 'foo');
  print(x);
}
